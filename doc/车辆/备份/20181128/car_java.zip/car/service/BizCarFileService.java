package com.ldz.biz.car.service;

import com.ldz.biz.car.model.BizCarFile;
import com.ldz.sys.base.BaseService;

public interface BizCarFileService extends BaseService<BizCarFile, java.lang.String> {

}
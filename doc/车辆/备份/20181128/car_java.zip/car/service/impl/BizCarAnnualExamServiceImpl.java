package com.ldz.biz.car.service.impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageInfo;
import com.ldz.biz.car.mapper.BizCarAnnualExamMapper;
import com.ldz.biz.car.model.BizCar;
import com.ldz.biz.car.model.BizCarAnnualExam;
import com.ldz.biz.car.model.BizCarWarn;
import com.ldz.biz.car.service.BizCarAnnualExamService;
import com.ldz.biz.car.service.BizCarService;
import com.ldz.biz.car.service.BizCarWarnService;
import com.ldz.sys.base.BaseServiceImpl;
import com.ldz.sys.base.LimitedCondition;
import com.ldz.sys.model.SysYh;
import com.ldz.util.bean.ApiResponse;
import com.ldz.util.bean.SimpleCondition;
import com.ldz.util.commonUtil.DateUtils;
import com.ldz.util.exception.RuntimeCheck;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tk.mybatis.mapper.common.Mapper;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class BizCarAnnualExamServiceImpl extends BaseServiceImpl<BizCarAnnualExam, String> implements BizCarAnnualExamService {

	@Autowired
	private BizCarAnnualExamMapper baseMapper;

	@Autowired
	private BizCarService carService;

	@Autowired
	private BizCarWarnService carWarnService;

	
	@Override
	protected Mapper<BizCarAnnualExam> getBaseMapper() {
		return baseMapper;
	}

	@Override
	public ApiResponse<String> validAndUpdate(BizCarAnnualExam exam){
		SysYh user=getCurrentUser(true);
		RuntimeCheck.ifBlank(exam.getId(),"请选择记录");
		BizCarAnnualExam obd=this.findById(exam.getId());
		RuntimeCheck.ifNull(obd,"请选择记录");
		String nslx=obd.getNslx();//年审类型  003	改气年审   002	运管年审   001	车管年审
		BizCar car=carService.findById(obd.getClId());
		exam.setJsyid(car.getSyrId());
		exam.setJsyxm(car.getSyrName());
		exam.setJsylxdh(car.getSyrDn());
//		exam.setJsysfzh(car.getsyr);
		exam.setZt("1");
		exam.setCjr(user.getZh()+"-"+user.getXm());
		exam.setCjsj(DateUtils.getNowTime());
		int i=baseMapper.updateByPrimaryKeySelective(exam);
		if(i>0){

			if(StringUtils.equals("001",nslx)){//车管年审
				car.setNsNsz(obd.getNsz());//年审至
				car.setNsNssj(obd.getNssj());//年审时间
				car.setNsJsyid(exam.getJsyid());//驾驶员ID
				car.setNsJsyxm(exam.getJsyxm());//驾驶员姓名
				car.setNsJsylxdh(exam.getJsylxdh());//驾驶员联系电话
				car.setNsZt("1");//年审状态
//				car.setNsLastData("");//上一次车管年审时间
			}else if(StringUtils.equals("002",nslx)){//运管年审

			}else if(StringUtils.equals("003",nslx)){//改气年审

			}

			carService.update(car);
		}
		BizCarWarn carWarn=new BizCarWarn();
		carWarn.setId(obd.getWarnId());
		carWarn.setWarnDispose("1");
		carWarnService.update(carWarn);

		carWarnService.updCarWarnDate(obd.getClId());
		return ApiResponse.success();
	}

	@Override
	public ApiResponse<List<BizCarAnnualExam>> getCarAnnualExamList(String clId){
		RuntimeCheck.ifBlank(clId, "请选择车辆的车辆。");
		SimpleCondition condition = new SimpleCondition(BizCarAnnualExam.class);
		condition.eq(BizCarAnnualExam.InnerColumn.clId,clId);
		condition.setOrderByClause(BizCarAnnualExam.InnerColumn.id.desc());
		List<BizCarAnnualExam> list=this.findByCondition(condition);
		if(list==null||list.size()<1){
			return ApiResponse.success(new Page<>());
		}
		return ApiResponse.success(list);

	}

	@Override
	public ApiResponse<Map<String, Long>> getPager(Page<BizCarAnnualExam> page) {
		ApiResponse<Map<String,Long>> result = new ApiResponse<>();

		LimitedCondition queryCondition = getQueryCondition();
		PageInfo<BizCarAnnualExam> pageInfo = findPage(page, queryCondition);

		result.setPage(pageInfo);

		SimpleCondition condition = new SimpleCondition(BizCarAnnualExam.class);
		// 所有未年审的车辆
		condition.and().andCondition(" zt != '1' ");
		List<BizCarAnnualExam> exams = findByCondition(condition);
		Map<String, Long> longMap = null;
		if(CollectionUtils.isNotEmpty(exams)) {

			longMap = exams.stream().collect(Collectors.groupingBy(BizCarAnnualExam::getNslx, Collectors.counting()));
			if (!longMap.containsKey("001")) {
				longMap.put("001", 0L);
			}
			if (!longMap.containsKey("002")) {
				longMap.put("002", 0L);
			}
			if (!longMap.containsKey("003")) {
				longMap.put("003", 0L);
			}

		}else {
			longMap = new HashMap<>();
			longMap.put("001",0L);
			longMap.put("002",0L);
			longMap.put("003",0L);
		}
		result.setResult(longMap);
		return result;
	}





}
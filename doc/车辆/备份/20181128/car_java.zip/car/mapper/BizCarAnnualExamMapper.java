package com.ldz.biz.car.mapper;

import com.ldz.biz.car.model.BizCarAnnualExam;
import com.ldz.util.mapperprovider.InsertListMapper;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;

public interface BizCarAnnualExamMapper extends Mapper<BizCarAnnualExam>, InsertListMapper<BizCarAnnualExam> {
    @Delete({
            "<script> " +
            " delete from biz_car_annual_exam where zt!='1' " +
            " and  warn_id  in " +
            " <foreach collection='list' item='item' open='(' close=')' separator=','> " +
            "  #{item} " +
            " </foreach> "
            +" </script>"
    })
    void insertDeleteList(@Param("list") List<String> warnIdList);
}
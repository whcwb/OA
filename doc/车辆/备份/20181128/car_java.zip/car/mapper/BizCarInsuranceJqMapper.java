package com.ldz.biz.car.mapper;

import com.ldz.biz.car.model.BizCarInsuranceJq;
import tk.mybatis.mapper.common.Mapper;

public interface BizCarInsuranceJqMapper extends Mapper<BizCarInsuranceJq> {
}
package com.ldz.biz.car.service;

import com.ldz.biz.car.model.BizCar;
import com.ldz.sys.base.BaseService;

/**
 * 车辆管理公共业务 JOB 消息下发等
 */
public interface BizCarMainService extends BaseService<BizCar, String> {

}
package com.ldz.biz.car.mapper;

import com.ldz.biz.car.model.BizCar;
import tk.mybatis.mapper.common.Mapper;

public interface BizCarMapper extends Mapper<BizCar> {
}
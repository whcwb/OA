package com.ldz.biz.car.service;

import com.ldz.biz.car.model.BizCar;
import com.ldz.sys.base.BaseService;
import com.ldz.util.bean.ApiResponse;

public interface BizCarService extends BaseService<BizCar, java.lang.String> {
    
    public ApiResponse<String> validAndSaveCar(BizCar entity);

    public ApiResponse<String> validAndUpdateCar(BizCar entity);

    public ApiResponse<String> updERecode(BizCar entity);
}
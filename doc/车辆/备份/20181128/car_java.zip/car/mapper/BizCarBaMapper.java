package com.ldz.biz.car.mapper;

import com.ldz.biz.car.model.BizCarBa;
import tk.mybatis.mapper.common.Mapper;

public interface BizCarBaMapper extends Mapper<BizCarBa> {
}
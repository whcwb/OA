package com.ldz.biz.car.mapper;

import com.ldz.biz.car.model.BizCarUsage;
import tk.mybatis.mapper.common.Mapper;

public interface BizCarUsageMapper extends Mapper<BizCarUsage> {
}
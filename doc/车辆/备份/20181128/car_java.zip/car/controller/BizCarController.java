package com.ldz.biz.car.controller;


import com.ldz.biz.car.model.BizCar;
import com.ldz.biz.car.service.BizCarService;
import com.ldz.sys.base.BaseController;
import com.ldz.sys.base.BaseService;
import com.ldz.util.bean.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * 车辆基础表
 */
@RestController
@RequestMapping("/api/car")
public class BizCarController extends BaseController<BizCar,String> {
    @Autowired
    private BizCarService service;

    @Override
    protected BaseService<BizCar, String> getBaseService() {
        return service;
    }

    /**
     * 车辆基础资料新增
     * @param entity
     * @return
     */
    @Override
    @RequestMapping(value="/save", method={RequestMethod.POST})
    public ApiResponse<String> save(BizCar entity){
        return service.validAndSaveCar(entity);
    }
    /**
     * 车辆基础资料修改
     * @param entity
     * @return
     */
    @Override
    @RequestMapping(value="/update", method={RequestMethod.POST})
    public ApiResponse<String> update(BizCar entity){
        return service.validAndUpdateCar(entity);
    }


    /**
     * 电子档案修改
     * @param entity
     *
     * @return
     */
    @RequestMapping(value="/dzda", method={RequestMethod.POST})
    public ApiResponse<String> updERecode(BizCar entity){
        return service.updERecode(entity);
    }

    /**
     * 获取车辆基本信息
     * @param clId
     * @return
     */
    @Override
    @RequestMapping(value="/get", method={RequestMethod.POST})
    public ApiResponse<BizCar> get(String clId){
        return ApiResponse.success(service.findById(clId));
    }


    @RequestMapping(value="/remove/{pkid}", method={RequestMethod.POST})
    public ApiResponse<String> remove(@PathVariable("pkid")String id){
        return ApiResponse.success();
//        return service.removeEntity(id);
    }

    @RequestMapping(value="/removeIds", method={RequestMethod.POST})
    public ApiResponse<String> remove(String[] ids){
        return ApiResponse.success();
//        return service.removeIds(ids);
    }

}
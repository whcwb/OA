package com.ldz.biz.car.service.impl;

import com.ldz.biz.car.mapper.BizCarMapper;
import com.ldz.biz.car.model.BizCar;
import com.ldz.biz.car.model.BizCarUsage;
import com.ldz.biz.car.model.BizCarWarn;
import com.ldz.biz.car.service.BizCarService;
import com.ldz.biz.car.service.BizCarUsageService;
import com.ldz.biz.car.service.BizCarWarnService;
import com.ldz.biz.model.CoachManagement;
import com.ldz.biz.service.CoachManagementService;
import com.ldz.biz.service.ZgjbxxService;
import com.ldz.sys.base.BaseServiceImpl;
import com.ldz.sys.base.LimitedCondition;
import com.ldz.sys.model.SysJg;
import com.ldz.sys.model.SysYh;
import com.ldz.sys.service.JgService;
import com.ldz.util.bean.ApiResponse;
import com.ldz.util.bean.SimpleCondition;
import com.ldz.util.commonUtil.DateUtils;
import com.ldz.util.exception.RuntimeCheck;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tk.mybatis.mapper.common.Mapper;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class BizCarServiceImpl extends BaseServiceImpl<BizCar, java.lang.String> implements BizCarService {

	@Autowired
	private BizCarMapper baseMapper;

	@Autowired
	private CoachManagementService jlService;//教练员

	@Autowired
	private JgService jgService;

	@Autowired
	private BizCarWarnService warnService;//提醒模板

	@Autowired
	private BizCarWarnService warnSservice;

	@Autowired
	private BizCarUsageService carUsageService;

	@Autowired
	private ZgjbxxService zgjbxxService;

	/**
	 * 分页补充
	 * queryWarnType  提醒类型(1、车辆年审提醒 2、运管年审提醒 3、改气年审提醒 4、续保提醒 5、报废提醒)
	 * queryWarnDay  90 天内 -1 表示查询过期的 为空表示该值无效 查询所有
	 *
	 * @param condition
	 * @return
	 */
	@Override
	public boolean fillPagerCondition(LimitedCondition condition){

		HttpServletRequest requset = getRequset();
		//提醒类型(1、车辆年审提醒 2、运管年审提醒 3、改气年审提醒 4、续保提醒 5、报废提醒)
		String queryWarnType = requset.getParameter("queryWarnType");
		//提醒提前通知的天数 queryWarnDay  90 天内 -1 表示查询过期的 为空表示查询所有
		String queryWarnDay = requset.getParameter("queryWarnDay");
		//	车辆状态   ZDCLK1042
		String carTypes=requset.getParameter("carType");
		if(StringUtils.isNotEmpty(carTypes)){
			String [] carTypeArray=carTypes.split(",");
			String whereSql="";
			for (String typ:carTypeArray){
				int typeInt=-1;
				try {
					//把字符串强制转换为数字
					typeInt=Integer.valueOf(typ);
					//如果是数字，返回True
				} catch (Exception e) {}
				if(typeInt>-1){
					whereSql+=" or car_type like  '%"+typeInt+"%' ";
				}
			}

			if(StringUtils.isNotEmpty(whereSql)){
				condition.and().andCondition("( 1=1"+whereSql+" )");
			}
		}

		String ccdjrq = requset.getParameter("ccdjrq");//初次登记日期
		// TODO: 2018/11/26   是否做改气操作，这里需要做一下验证
//		if(StringUtils.equals(ccdjrq,"1")){
//			condition.in(BizCar.InnerColumn.id, list);
//		}else if(StringUtils.equals(ccdjrq,"0")){
//
//		}
		String qzbfq = requset.getParameter("qzbfq");//强制报废期
		String bxCdrq = requset.getParameter("bxCdrq");//保险初登日期
		String yyCdrq = requset.getParameter("yyCdrq");//运管初登日期
		String gxCdrq = requset.getParameter("gxCdrq");//改气初登日期

		if(StringUtils.isNotBlank(queryWarnType)){
			SimpleCondition simpleCondition = new SimpleCondition(BizCarWarn.class);

			simpleCondition.lte(BizCarWarn.InnerColumn.warnDate, DateUtils.getToday());
			simpleCondition.eq(BizCarWarn.InnerColumn.warnType, queryWarnType);
			simpleCondition.eq(BizCarWarn.InnerColumn.warnDispose, "0");//查询所有未处理的告警信息
			if(StringUtils.isNotEmpty(queryWarnDay)){
				Integer queryWarnDays=null;
				try {
					queryWarnDays=Integer.parseInt(queryWarnDay);
				}catch (Exception e){}
				if(queryWarnDays!=null&&queryWarnDays>-1){
//					condition.and().andCondition(" charge_code = 9999 or charge_code = 4999 ");
					simpleCondition.and().andCondition(" (TIMESTAMPDIFF(DAY , now(),expiry_date)>0 and TIMESTAMPDIFF(DAY , now(),expiry_date)< "+queryWarnDays+") ");
				}else if(queryWarnDays==-1){
//					simpleCondition.and().andCondition(" (TIMESTAMPDIFF(DAY ,expiry_date, now())<0 and TIMESTAMPDIFF(DAY ,expiry_date, now())< "+queryWarnDays+") ");
					simpleCondition.and().andCondition(" (TIMESTAMPDIFF(DAY , now(),expiry_date)<0 ) ");
				}
			}

			List<BizCarWarn> institutions = warnSservice.findByCondition(simpleCondition);
			List<String> list = institutions.stream().map(BizCarWarn::getClId).collect(Collectors.toList());
			if(CollectionUtils.isNotEmpty(list)) {
				condition.in(BizCar.InnerColumn.id, list);
			}
		}
		return true;
	}


	
	@Override
	protected Mapper<BizCar> getBaseMapper() {
		return baseMapper;
	}

	/**
	 * 新增操作
	 * @param entity
	 * @return
	 */
	@Override
	public ApiResponse<String> validAndSaveCar(BizCar entity) {
		SysYh currentUser=getCurrentUser(true);
		RuntimeCheck.ifFalse(StringUtils.equals(currentUser.getJgdm(),"100"), "您所在的角色无权新增车辆。");
//		1、非空验证
		RuntimeCheck.ifBlank(entity.getCph(), "请填写车牌号");
		RuntimeCheck.ifBlank(entity.getDah(), "请填写档案号");
		RuntimeCheck.ifBlank(entity.getPxcx(), "请选择培训车型");
		RuntimeCheck.ifBlank(entity.getHpzl(), "请选择号牌种类");
		RuntimeCheck.ifBlank(entity.getSyxz(), "请选择使用性质");
		RuntimeCheck.ifBlank(entity.getCcdjrq(), "请输入初次登记日期");
//		RuntimeCheck.ifBlank(entity.getQzbfq(), "请输入强制报废期");
//		2、字典项有效验证  todo 后期需要从字典表中获取
		RuntimeCheck.ifFalse(StringUtils.indexOf(",C1,C2,A1,A2,A3,B2",","+entity.getPxcx())>-1, "培训车型填写错误，请重新填写");
		RuntimeCheck.ifFalse(StringUtils.indexOf(",1,2",","+entity.getHpzl())>-1, "号牌种类填写错误，请重新填写");
		RuntimeCheck.ifFalse(StringUtils.indexOf(",1,2,3",","+entity.getSyxz())>-1, "使用性质填写错误，请重新填写");
		try {
			if(StringUtils.isNotEmpty(entity.getCcdjrq())){
				DateUtils.getDate(entity.getCcdjrq(),"yyyy-MM-dd");
			}
		}catch (Exception e){
			e.printStackTrace();
			RuntimeCheck.ifTrue(true,"请输入正确的初次登记日期 日期格式为：yyyy-MM-dd");
		}
		try {
			if(StringUtils.isNotEmpty(entity.getQzbfq())){
				DateUtils.getDate(entity.getQzbfq(),"yyyy-MM-dd");
			}
		}catch (Exception e){
			e.printStackTrace();
			RuntimeCheck.ifTrue(true,"请输入正确的强制报废期 日期格式为：yyyy-MM-dd");
		}
//		3、车牌号、档案号去重验证
		SimpleCondition validateCondition = new SimpleCondition(BizCar.class);
		validateCondition.and().andEqualTo(BizCar.InnerColumn.cph.name(), entity.getCph());//请填写车牌号
		validateCondition.or().andEqualTo(BizCar.InnerColumn.dah.name(), entity.getDah());//请填写档案号
		List<BizCar> validateList=this.findByCondition(validateCondition);
		if(validateList!=null&&validateList.size()>0){
			for(BizCar vCar:validateList){
				RuntimeCheck.ifTrue(StringUtils.equals(vCar.getCph(),entity.getCph()), "车牌号已经存在，请重新填写");
				RuntimeCheck.ifTrue(StringUtils.equals(vCar.getDah(),entity.getDah()), "档案号已经存在，请重新填写");
			}
		}

//		4、获取所有机构代码对应的机构名称
		SimpleCondition condition = new SimpleCondition(SysJg.class);
		condition.eq(SysJg.InnerColumn.zt,"10");
		List<SysJg> all = jgService.findByCondition(condition);
		Map<String, String> jgMap = all.stream().collect(Collectors.toMap(SysJg::getJgdm, SysJg::getJgmc));
		entity.setId(genId());
		entity.setJgdm(currentUser.getJgdm());
		entity.setJgmc(jgMap.get(currentUser.getJgdm()));
		entity.setCjr(currentUser.getZh()+"-"+currentUser.getXm());
		entity.setCjsj(DateUtils.getNowTime());
//		车辆产权状态 [ZDCLK1041]  1、学牌车 2、非学牌车 3、已报销车 4、已售出
		String carPropertyType="2";
		if(StringUtils.equals(entity.getHpzl(),"1")){//1、学牌 2、地牌
			carPropertyType="1";
		}
		entity.setCarPropertyType(carPropertyType);

//		5、通过 初次登记日期 核算出所有的预警信息
		if(StringUtils.isEmpty(entity.getCcdjrq())){
			baseMapper.insertSelective(entity);
		}else{
			ApiResponse<String> warnType=warnService.batchAnnualSave(entity,null);
			if(warnType.isSuccess()){
				baseMapper.insertSelective(entity);
				warnService.updCarWarnDate(entity.getId());
			}else{
				return warnType;
			}
		}
//	 * clId     车辆ID
//	 * syrId   使用人编号，从人事表中获取。非必填字段
//				* syrName   使用人姓名
//				* syrSzd   使用人所在地
//				* syrDn   使用人联系方式
		String syrId=entity.getSyrId();
		String sysName=entity.getSyrName();
		String sysSzd=entity.getSyrSzd();
		String sysDn=entity.getSyrDn();
		String syrSzd=entity.getSyrSzd();
		if(StringUtils.isNotEmpty(syrId)){
			CoachManagement zgjbxx = jlService.findById(syrId);
			if(zgjbxx!=null){
				sysName=zgjbxx.getCoachName();
				sysDn=zgjbxx.getPhone();
				syrSzd=zgjbxx.getArea();//所属区域
			}

		}
		BizCarUsage carUsage=new BizCarUsage();
		carUsage.setClId(entity.getId());
		carUsage.setSyrId(syrId);
		carUsage.setSyrName(sysName);
		carUsage.setSyrSzd(sysSzd);
		carUsage.setSyrDn(sysDn);
		carUsage.setSyrSzd(syrSzd);//使用人所在地
		carUsageService.validAndSaveUsage(carUsage);

		return ApiResponse.success();
	}

	@Override
	public ApiResponse<String> validAndUpdateCar(BizCar entity){
		SysYh user=getCurrentUser(true);
		RuntimeCheck.ifFalse(StringUtils.equals(user.getJgdm(),"100"), "您所在的角色无权修改车辆信息。");
//		1、非空验证
		RuntimeCheck.ifBlank(entity.getId(), "该车辆不存在，请核实");
		RuntimeCheck.ifBlank(entity.getCph(), "请填写车牌号");
		RuntimeCheck.ifBlank(entity.getDah(), "请填写档案号");
		RuntimeCheck.ifBlank(entity.getPxcx(), "请选择培训车型");
		RuntimeCheck.ifBlank(entity.getHpzl(), "请选择号牌种类");
		RuntimeCheck.ifBlank(entity.getSyxz(), "请选择使用性质");
		RuntimeCheck.ifBlank(entity.getCcdjrq(), "请输入初次登记日期");
//		RuntimeCheck.ifBlank(entity.getQzbfq(), "请输入强制报废期");
//		2、字典项有效验证  todo 后期需要从字典表中获取
		RuntimeCheck.ifFalse(StringUtils.indexOf(",C1,C2,A1,A2,A3,B2",","+entity.getPxcx())>-1, "培训车型填写错误，请重新填写");
		RuntimeCheck.ifFalse(StringUtils.indexOf(",1,2",","+entity.getHpzl())>-1, "号牌种类填写错误，请重新填写");
		RuntimeCheck.ifFalse(StringUtils.indexOf(",1,2,3",","+entity.getSyxz())>-1, "使用性质填写错误，请重新填写");
		try {
			if(StringUtils.isNotEmpty(entity.getCcdjrq())){
				DateUtils.getDate(entity.getCcdjrq(),"yyyy-MM-dd");
			}
		}catch (Exception e){
			e.printStackTrace();
			RuntimeCheck.ifTrue(true,"请输入正确的初次登记日期 日期格式为：yyyy-MM-dd");
		}
		try {
			if(StringUtils.isNotEmpty(entity.getQzbfq())){
				DateUtils.getDate(entity.getQzbfq(),"yyyy-MM-dd");
			}
		}catch (Exception e){
			e.printStackTrace();
			RuntimeCheck.ifTrue(true,"请输入正确的强制报废期 日期格式为：yyyy-MM-dd");
		}

//		3、验证当前用户是否有权限修改这台车数据。
		BizCar findBy=this.findById(entity.getId());
		RuntimeCheck.ifNull(findBy, "该车辆不存在，请核实");
		RuntimeCheck.ifFalse(StringUtils.indexOf(findBy.getJgdm(),user.getJgdm())>-1, "该车辆属于："+findBy.getJgmc()+" 您无权编辑它");
//		RuntimeCheck.ifTrue(StringUtils.equals(findBy.getCarPropertyType(),"2"), "该车辆已经是，不能做编辑操作。");
		RuntimeCheck.ifTrue(StringUtils.equals(findBy.getCarPropertyType(),"3"), "该车辆已经报废，不能做编辑操作。");
		RuntimeCheck.ifTrue(StringUtils.equals(findBy.getCarPropertyType(),"4"), "该车辆已经售出，不能做编辑操作。");

//		4、车牌号、档案号去重验证
		SimpleCondition validateCondition = new SimpleCondition(BizCar.class);
		validateCondition.and().andEqualTo(BizCar.InnerColumn.cph.name(), entity.getCph());//请填写车牌号
		validateCondition.or().andEqualTo(BizCar.InnerColumn.dah.name(), entity.getDah());//请填写档案号
		List<BizCar> validateList=this.findByCondition(validateCondition);
		if(validateList!=null&&validateList.size()>0){
			for(BizCar vCar:validateList){
				if(!StringUtils.equals(vCar.getId(),entity.getId())){
					RuntimeCheck.ifTrue(StringUtils.equals(vCar.getCph(),entity.getCph()), "车牌号已经存在，请重新填写");
					RuntimeCheck.ifTrue(StringUtils.equals(vCar.getDah(),entity.getDah()), "档案号已经存在，请重新填写");
				}
			}
		}

//		车辆产权状态 [ZDCLK1041]  1、学牌车 2、非学牌车 3、已报销车 4、已售出
		String carPropertyType="2";
		if(StringUtils.equals(entity.getHpzl(),"1")){//1、学牌 2、地牌
			carPropertyType="1";
		}
		entity.setCarPropertyType(carPropertyType);
		entity.setCph(findBy.getCph());//车辆编辑时，车牌号不能被编辑


//		5、通过 初次登记日期 核算出所有的预警信息
		if(StringUtils.isEmpty(entity.getCcdjrq())){
			baseMapper.updateByPrimaryKeySelective(entity);
		}else{
			ApiResponse<String> warnType=warnService.batchAnnualSave(entity,findBy);
			if(warnType.isSuccess()){
				baseMapper.updateByPrimaryKeySelective(entity);
				warnService.updCarWarnDate(entity.getId());
			}else{
				return warnType;
			}
		}

		//	 * clId     车辆ID
//	 * syrId   使用人编号，从人事表中获取。非必填字段
//				* syrName   使用人姓名
//				* syrSzd   使用人所在地
//				* syrDn   使用人联系方式
		String syrId=entity.getSyrId();
		String sysName=entity.getSyrName();
		String sysSzd=entity.getSyrSzd();
		String sysDn=entity.getSyrDn();
		String syrSzd=entity.getSyrSzd();

		if(StringUtils.isNotEmpty(syrId)){
			CoachManagement zgjbxx = jlService.findById(syrId);
			if(zgjbxx!=null){
				sysName=zgjbxx.getCoachName();
				sysDn=zgjbxx.getPhone();
				syrSzd=zgjbxx.getArea();//所属区域
			}
		}
		BizCarUsage carUsage=new BizCarUsage();
		carUsage.setClId(entity.getId());
		carUsage.setSyrId(syrId);
		carUsage.setSyrName(sysName);
		carUsage.setSyrSzd(sysSzd);
		carUsage.setSyrDn(sysDn);
		carUsage.setSyrSzd(syrSzd);//使用人所在地
		carUsageService.validAndSaveUsage(carUsage);

		return ApiResponse.success();
	}

	/**
	 * 修改车辆电子档
	 * @param entity
	 * @return
	 */
	public ApiResponse<String> updERecode(BizCar entity){
		SysYh user=getCurrentUser(true);
		RuntimeCheck.ifFalse(StringUtils.equals(user.getJgdm(),"100"), "您所在的角色无权修改车辆信息。");
//		1、非空验证
		RuntimeCheck.ifBlank(entity.getId(), "该车辆不存在，请核实");

		BizCar findBy=this.findById(entity.getId());
		RuntimeCheck.ifNull(findBy, "该车辆不存在，请核实");
		RuntimeCheck.ifFalse(StringUtils.indexOf(findBy.getJgdm(),user.getJgdm())>-1, "该车辆属于："+findBy.getJgmc()+" 您无权编辑它");

//		2、电子证验证
//		2-1、电子证验证 检查机动机电子证
		findBy.setDzdDjzCode(entity.getDzdDjzCode());//机动车登记证书编号
		if(StringUtils.isNotEmpty(entity.getDzdDjzFileurl())){
			findBy.setDzdDjzFileurl(entity.getDzdDjzFileurl());
			findBy.setDzdDjzType("1");
		}else{
			findBy.setDzdDjzFileurl("");
			findBy.setDzdDjzType("0");
		}
//		2-2、电子证验证 检查机动机电子证
		findBy.setDzdWszmCode(entity.getDzdWszmCode());//购置税完税证明证号
		findBy.setDzdWszmPh(entity.getDzdWszmPh());//购置税完税证明票号
		if(StringUtils.isNotEmpty(entity.getDzdWszmFileurl())){
			findBy.setDzdWszmFileurl(entity.getDzdWszmFileurl());//购置税完税证明票号电子档路径
			findBy.setDzdWszmType("1");
		}else{
			findBy.setDzdWszmType("0");
			findBy.setDzdWszmFileurl("");
		}
//		2-3、电子证验证 发票状态
		findBy.setDzdFpCode(entity.getDzdFpCode());
		if(StringUtils.isNotEmpty(entity.getDzdFpFileurl())){
			findBy.setDzdFpFileurl(entity.getDzdFpFileurl());
			findBy.setDzdFpType("1");
		}else{
			findBy.setDzdFpFileurl("");
			findBy.setDzdFpType("0");
		}
//		2-4、电子证验证 出厂合格证明
		if(StringUtils.isNotEmpty(entity.getDzdDrysFileurl())){
			findBy.setDzdDrysFileurl(entity.getDzdDrysFileurl());
			findBy.setDzdDrysFileurl("1");
		}else{
			findBy.setDzdDrysFileurl("");
			findBy.setDzdDrysFileurl("0");
		}
////		2-5、电子证验证 检验合格证明
//		if(StringUtils.isNotEmpty(entity.getDzdJyhgFileurl())){
//			findBy.setDzdJyhgFileurl(entity.getDzdJyhgFileurl());
//			findBy.setDzdJyhgType("1");
//		}else{
//			findBy.setDzdJyhgFileurl("");
//			findBy.setDzdJyhgType("0");
//		}
////		2-6、电子证验证 修理合格证明
//		if(StringUtils.isNotEmpty(entity.getDzdXlhgFileurl())){
//			findBy.setDzdXlhgFileurl(entity.getDzdXlhgFileurl());
//			findBy.setDzdXlhgType("1");
//		}else {
//			findBy.setDzdXlhgFileurl("");
//			findBy.setDzdXlhgType("0");
//
//		}
//		2-7、电子证验证 行驶证扫描件状态
		if(StringUtils.isNotEmpty(entity.getDzdXszfyFileurl())){
			findBy.setDzdXszfyFileurl(entity.getDzdXszfyFileurl());
			findBy.setDzdXszfyType("1");
		}else{
			findBy.setDzdXszfyFileurl("");
			findBy.setDzdXszfyType("0");
		}
		baseMapper.updateByPrimaryKeySelective(findBy);
//		baseMapper.updateByPrimaryKey(findBy);
		return ApiResponse.success();
	}
}
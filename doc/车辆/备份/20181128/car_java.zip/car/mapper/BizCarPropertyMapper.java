package com.ldz.biz.car.mapper;

import com.ldz.biz.car.model.BizCarProperty;
import tk.mybatis.mapper.common.Mapper;

public interface BizCarPropertyMapper extends Mapper<BizCarProperty> {
}
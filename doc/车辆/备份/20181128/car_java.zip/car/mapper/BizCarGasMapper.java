package com.ldz.biz.car.mapper;

import com.ldz.biz.car.model.BizCarGas;
import tk.mybatis.mapper.common.Mapper;

public interface BizCarGasMapper extends Mapper<BizCarGas> {
}